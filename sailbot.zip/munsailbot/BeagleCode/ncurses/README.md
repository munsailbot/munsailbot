SailbotBrain depends on ncurses for debug output in its current state.

ncurses must be cross-compiled for ARM separately and the resulting include and library files 
placed in the respective directories here.