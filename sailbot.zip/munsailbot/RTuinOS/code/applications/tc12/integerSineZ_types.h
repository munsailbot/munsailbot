/*
 * File: integerSineZ_types.h
 *
 * Real-Time Workshop code generated for Simulink model integerSineZ.
 *
 * Model version                        : 1.12
 * Real-Time Workshop file version      : 7.3  (R2009a)  15-Jan-2009
 * Real-Time Workshop file generated on : Wed Jun 12 21:11:49 2013
 * TLC version                          : 7.3 (Jan 18 2009)
 * C/C++ source code generated on       : Wed Jun 12 21:11:49 2013
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_integerSineZ_types_h_
#define RTW_HEADER_integerSineZ_types_h_
#include "rtwtypes.h"

/* Forward declaration for rtModel */
typedef struct RT_MODEL_integerSineZ RT_MODEL_integerSineZ;

#endif                                 /* RTW_HEADER_integerSineZ_types_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
