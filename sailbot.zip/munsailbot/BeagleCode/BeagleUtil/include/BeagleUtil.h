/*
Daniel Cook 2013
daniel@daniel-cook.net
*/

#ifndef __BEAGLEUTIL_H
#define __BEAGLEUTIL_H

#include "GPIO.h"
#include "I2C.h"
#include "PWM.h"
#include "UART.h"
#include "UARTInterface.h"

#endif
